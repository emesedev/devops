const routes = [
  // Auth pages
  {
    path: '/',
    component: () => import('../views/Login/LoginPage.vue'),
  },
  {
    path: '/dashboard/admin',
    component: () => import('../views/Dashboard/Admin.vue'),
  },
  {
    path: '/dashboard/',
    component: () => import('../views/Dashboard/Dashboard.vue'),
  },
  {
    path: '/users',
    component: () => import('../views/Users/UsersPage.vue'),
  },
  {
    path: '/equipment',
    component: () => import('../views/Equipments/EquipmentPage.vue'),
  },
  // Always leave this last
  {
    path: '/:catchAll(.*)*',
    component: () => import('../views/ErrorNotFound.vue'),
  },
];

export default routes;
