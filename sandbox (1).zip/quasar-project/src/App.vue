<template>
  <div id="app">
    <!-- 1. Mostrar Sidebar solo si NO estamos en la ruta de login -->
    <Sidebar 
      v-if="showSidebar" 
      @toggle-sidebar="updateCollapseState" 
      @logout="handleLogout"
    />
    
    <!-- 2. Usar la propiedad computada para el margen dinámico -->
    <main class="main-content" :style="{ 'margin-left': calculatedMainContentMargin + 'px' }">
      <router-view></router-view>
    </main>
  </div>
</template>

<script lang="ts">
import Sidebar from './views/Menu/Sidebar.vue';
import { defineComponent } from 'vue';

// Ruta exacta de tu componente de Login
const LOGIN_ROUTE_PATH = '/'; 

export default defineComponent({
  name: 'App',
  components: {
    Sidebar,
  },
  data() {
    return {
      // Estado de la barra lateral
      isSidebarCollapsed: false,
      sidebarCollapsedWidth: 60,
      sidebarExpandedWidth: 250,
    };
  },
  
  computed: {
    // Propiedad computada para determinar si se debe mostrar el sidebar
    showSidebar(): boolean {
      // El Sidebar se muestra en CUALQUIER ruta excepto /login.
      return this.$route.path !== LOGIN_ROUTE_PATH;
    },
    
    // Propiedad computada para calcular el margen del contenido principal
    calculatedMainContentMargin(): number {
      if (!this.showSidebar) {
        // Si el sidebar está oculto (ruta de login), el margen es 0
        return 0;
      }
      
      // Si el sidebar está visible, aplica el margen basado en su estado
      return this.isSidebarCollapsed 
        ? this.sidebarCollapsedWidth 
        : this.sidebarExpandedWidth;
    }
  },

  methods: {
    /**
     * Actualiza el estado de colapso emitido por el Sidebar.
     * @param isCollapsed - Indica si el sidebar está colapsado (true) o expandido (false).
     */
    updateCollapseState(isCollapsed: boolean) {
      this.isSidebarCollapsed = isCollapsed;
    },

    /**
     * Maneja el "cierre de sesión" (solo redirige al login, ya que no hay estado de sesión).
     */
    handleLogout() {
      void this.$router.push(LOGIN_ROUTE_PATH);
    }
  },
});
</script>

<style>
body {
  margin: 0;
  font-family:Arial, Helvetica, sans-serif;
}

/* El contenedor principal debe ser flex para que main-content crezca y ocupe el espacio */
#app {
  display: flex;
}

.main-content {
  flex-grow: 1;
  /* El margen es manejado por el estilo dinámico en el template */
  transition: margin-left 0.3s ease; 
  background-color: #eee;
  min-height: 100vh; /* Asegura que la vista ocupe al menos toda la altura */
  width: 100%; 
  box-sizing: border-box; /* Incluye padding en el cálculo del ancho */
}
</style>