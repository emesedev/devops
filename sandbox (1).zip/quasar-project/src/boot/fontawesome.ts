// src/boot/fontawesome.ts

import { library } from '@fortawesome/fontawesome-svg-core';
import { FontAwesomeIcon } from '@fortawesome/vue-fontawesome';
import { 
    // Importa los íconos que realmente estás usando en tu sidebar
    faHome, faChartLine, faUsers, faCogs, faTools, faCalendarDays, faScroll, 
    faEllipsisH, faSignOutAlt, faBars, faChevronUp, faChevronDown, faBell, 
    faClipboardList, faCalendarCheck, faListCheck, faTriangleExclamation,
    faGasPump, faLightbulb, faHandSparkles, faClockRotateLeft, faCheckDouble,
    faFileInvoice, faGaugeHigh, faChartPie, faFileCircleCheck, faBug,
    faScrewdriverWrench, faBarsStaggered
} from '@fortawesome/free-solid-svg-icons';
import { boot } from 'quasar/wrappers';
import type { App } from 'vue'; // 🟢 CORRECCIÓN: Usar 'import type'

// 1. Añade los íconos a la librería global para que estén disponibles
library.add(
    faHome, faChartLine, faUsers, faCogs, faTools, faCalendarDays, faScroll, 
    faEllipsisH, faSignOutAlt, faBars, faChevronUp, faChevronDown, faBell, 
    faClipboardList, faCalendarCheck, faListCheck, faTriangleExclamation,
    faGasPump, faLightbulb, faHandSparkles, faClockRotateLeft, faCheckDouble,
    faFileInvoice, faGaugeHigh, faChartPie, faFileCircleCheck, faBug,
    faScrewdriverWrench, faBarsStaggered
);

// 2. Exporta la función boot para Quasar
export default boot(({ app }: { app: App }) => {
  // 3. Registra el componente global de Font Awesome
  app.component('font-awesome-icon', FontAwesomeIcon);
});