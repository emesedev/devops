<template>
    <div class="dashboard-container">
        <div class="dashboard-card table-card">
            <div class="card-header">
                <div class="header-content">
                    <font-awesome-icon :icon="['fas', 'user']" class="header-icon" />
                    <span class="card-title">Equipos</span>
                </div>
                <div class="header-actions">
                    <button class="add-btn" @click="isWizardVisible = true">
                        <font-awesome-icon :icon="['fas', 'plus']" />
                        Agregar Equipo
                    </button>
                </div>
            </div>
            <div class="card-content">
                <table>
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Nombre</th>
                            <th>Localización</th>
                            <th>Responsable</th>
                            <th>Área</th>
                            <th>Estatus</th>
                            <th>Acción</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr v-for="item in tableData" :key="item.id">
                            <td>{{ item.id }}</td>
                            <td>{{ item.name }}</td>
                            <td>{{ item.location }}</td>
                            <td>{{ item.responsible }}</td>
                            <td>{{ item.area }}</td>
                            <td>
                                <span :class="['status-badge', getStatusClass(item.status)]">{{
                                    item.status }}</span>
                            </td>
                            <td class="action-buttons">
                                <button class="action-btn edit-btn" @click="openModal('edit', item)">
                                    <font-awesome-icon :icon="['fas', 'edit']" />
                                </button>
                                <button class="action-btn delete-btn" @click="openModal('delete', item)">
                                    <font-awesome-icon :icon="['fas', 'trash-alt']" />
                                </button>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>

        <div class="modal-backdrop" v-if="isWizardVisible" @click="isWizardVisible = false">
            <div class="modal-content-wizard" @click.stop>
                <button class="modal-close-btn" @click="isWizardVisible = false">&times;</button>
                <Wizard @finish-wizard="handleWizardFinish" />
            </div>
        </div>

        <div class="modal-backdrop" v-if="isModalVisible" @click="closeModal">
            <div class="modal-content-default" @click.stop>
                <button class="modal-close-btn" @click="closeModal">&times;</button>
                <div class="modal-header">
                    <h2>{{ modalTitle }}</h2>
                </div>
                <div class="modal-body">
                    <form v-if="modalAction === 'edit' && selectedItem" @submit.prevent="handleAction" class="modal-form">
                        <div class="modal-form-grid">
                            <div class="form-group">
                                <label>ID:</label>
                                <input type="text" v-model="selectedItem.id" disabled>
                            </div>
                            <div class="form-group">
                                <label>Nombre:</label>
                                <input type="text" v-model="selectedItem.name" required>
                            </div>
                            <div class="form-group">
                                <label>Localización:</label>
                                <input type="text" v-model="selectedItem.location">
                            </div>
                            <div class="form-group">
                                <label>No. Facility:</label>
                                <input type="text" v-model="selectedItem.fa_number">
                            </div>

                            <div class="form-group">
                                <label>Clase:</label>
                                <select v-model="selectedItem.class">
                                    <option v-for="cl in classes" :key="cl" :value="cl">{{ cl }}</option>
                                </select>
                            </div>

                            <div class="form-group">
                                <label>Categoría:</label>
                                <select v-model="selectedItem.category">
                                    <option v-for="cat in categories" :key="cat" :value="cat">{{ cat }}</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Área:</label>
                                <select v-model="selectedItem.area">
                                    <option v-for="ar in areas" :key="ar" :value="ar">{{ ar }}</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Frecuencia:</label>
                                <select v-model="selectedItem.frequency">
                                    <option v-for="freq in frequencies" :key="freq" :value="freq">{{ freq }}</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Responsable:</label>
                                <select v-model="selectedItem.responsible">
                                    <option v-for="resp in responsibles" :key="resp" :value="resp">{{ resp }}</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Planta:</label>
                                <select v-model="selectedItem.plant">
                                    <option v-for="pl in plants" :key="pl" :value="pl">{{ pl }}</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Estatus:</label>
                                <select v-model="selectedItem.status">
                                    <option value="Active">Activo</option>
                                    <option value="Inactive">Inactivo</option>
                                </select>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="action-btn cancel-btn" @click="closeModal">Cancelar</button>
                            <button type="submit" class="action-btn confirm-btn">Guardar</button>
                        </div>
                    </form>

                    <div v-else-if="modalAction === 'delete' && selectedItem">
                        <p>¿Estás seguro que quieres eliminar <strong>{{ selectedItem.name }}</strong>?</p>
                        <div class="modal-footer">
                            <button type="button" class="action-btn cancel-btn" @click="closeModal">Cancelar</button>
                            <button class="action-btn delete-confirm-btn" @click="handleAction">Confirmar</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script lang="ts">
import { defineComponent } from 'vue';
// Asumo que Wizard está importado correctamente, si no, asegúrate de importarlo
// import Wizard from './Wizard.vue'; 

interface User {
    id: number;
    name: string;
    location: string;
    fa_number: string;
    class: string;
    area: string;
    frequency: string;
    responsible: string;
    plant: string;
    category: string;
    status: 'Activo' | 'Inactivo';
}

interface ComponentData {
    isWizardVisible: boolean;
    isModalVisible: boolean;
    modalAction: 'edit' | 'delete' | '';
    modalTitle: string;
    selectedItem: User | null;
    classes: string[];
    areas: string[];
    frequencies: string[];
    responsibles: string[];
    categories: string[];
    plants: string[];
    tableData: User[];
}

export default defineComponent({
    name: 'EquiposDashboard',
    components: {
        // Wizard 
    },
    data(): ComponentData {
        return {
            isWizardVisible: false,
            isModalVisible: false,
            modalAction: '',
            modalTitle: '',
            selectedItem: null,

            // --- Listas de Opciones para los Selects ---
            areas: ['Mechanics', 'Electrical', 'General Services', 'Servicios Generales', 'HVAC', 'PTAR'],
            frequencies: ['Daily', 'Weekly', 'Biweekly', 'Monthly', 'Quarterly', 'Semiannual', 'Annual'],
            responsibles: ['Melecio Ornelas', 'Jose Alejandro Vieyra', 'Jose Guadalupe Esparza', 'Luis Alberto Field', 'Jose Jair Olmedo'],
            plants: ['Thermal', 'PowerTrain', 'BTM'],
            categories: ['Compressor', 'HVAC', 'Electrical', 'Mechanical', 'Building'],
            classes: ['A', 'B', 'C'],

            tableData: [
                { id: 1, name: 'Compresor Velocidad Variable', location: 'Compresores Thermal', fa_number: 'FA-001', class: '1', area: 'Mecanicos 1', frequency: 'Monthly', responsible: 'Melecio Ornelas', plant: 'Thermal', category: 'Compressor', status: 'Activo' as const },
                { id: 2, name: 'Minisplit', location: 'HVAC L1', fa_number: 'FA-002', class: '2', area: 'Mecanicos 1', frequency: 'Quarterly', responsible: 'Jose Alejandro Vieyra', plant: 'Thermal', category: 'HVAC', status: 'Activo' as const },
                { id: 3, name: 'Transformador De 34.5kV', location: 'Subestacion Thermal', fa_number: 'FA-003', class: '3', area: 'Electricos', frequency: 'Annual', responsible: 'Jose Guadalupe Esparza', plant: 'Thermal', category: 'Electrical', status: 'Activo' as const },
                { id: 4, name: 'Motoreductor Tanque Agua', location: 'PTAR', fa_number: 'FA-004', class: '4', area: 'Mecanicos 2', frequency: 'Semiannual', responsible: 'Luis Alberto Field', plant: 'Thermal', category: 'Mechanical', status: 'Inactivo' as const },
                { id: 5, name: 'Grua Viajera 8t P-2243', location: 'HVAC', fa_number: 'FA-005', class: '1', area: 'Servicios Generales', frequency: 'Annual', responsible: 'Jose Jair Olmedo', plant: 'Thermal', category: 'Mechanical', status: 'Activo' as const },
            ],
        };
    },
    methods: {
        // Abre el modal y carga los datos del ítem seleccionado
        openModal(action: 'edit' | 'delete', item: User): void {
            this.modalAction = action;
            this.modalTitle = action === 'edit' ? 'Editar Equipo' : 'Eliminar Equipo';
            // Creamos una copia superficial para no mutar la tabla directamente
            this.selectedItem = { ...item };
            this.isModalVisible = true;
        },

        // Cierra el modal y limpia la selección
        closeModal(): void {
            this.isModalVisible = false;
            this.modalAction = '';
            this.selectedItem = null;
        },

        // Maneja la acción de cerrar el Wizard
        handleWizardFinish(): void {
            this.isWizardVisible = false;
            // Aquí podrías agregar lógica para recargar la tabla si el Wizard devuelve datos
            console.log('Wizard finalizado');
        },

        // Ejecuta la acción de Guardar (Edit) o Confirmar (Delete)
        handleAction(): void {
            if (!this.selectedItem) return;

            if (this.modalAction === 'edit') {
                const index = this.tableData.findIndex(item => item.id === this.selectedItem!.id);
                if (index !== -1) {
                    // Actualizamos el registro en la tabla local
                    this.tableData.splice(index, 1, this.selectedItem);
                }
            } else if (this.modalAction === 'delete') {
                // Eliminamos el registro de la tabla local
                this.tableData = this.tableData.filter(item => item.id !== this.selectedItem!.id);
            }
            this.closeModal();
        },

        getStatusClass(status: string): string {
            const statusMap: Record<string, string> = {
                'Activo': 'status-active',
                'Active': 'status-active',
                'Inactivo': 'status-inactive',
                'Inactive': 'status-inactive',
            };
            return statusMap[status] || '';
        }
    },
});
</script>

<style scoped>
/* --- Estilos --- */
.dashboard-container {
    display: flex;
    gap: 10px;
    padding: 15px;
}

.dashboard-card {
    background-color: #fff;
    border-radius: 10px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    overflow: hidden;
    flex: 1;
}

table {
    width: 100%;
    border-collapse: collapse;
}

th,
td {
    padding: 15px;
    text-align: left;
    border-bottom: 1px solid #ddd;
    color: #6b7280;
}

th {
    font-weight: bold;
    text-transform: uppercase;
    font-size: 14px;
    color: #000;
}

thead tr {
    background-color: #fff;
}

tbody tr:hover {
    background-color: #f9f9f9;
}

.card-header {
    background-color: #fff;
    color: #000;
    padding: 10px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    border-bottom: 1px solid #ddd;
    border-color: #000;
}

.header-content {
    display: flex;
    align-items: center;
    gap: 15px;
}

.header-actions {
    display: flex;
    align-items: center;
}

.header-icon {
    font-size: 30px;
    color: #0092d6;
    background-color: #e8f5e9;
    padding: 10px;
    border-radius: 5px;
}

.card-title {
    font-weight: bold;
    color: #444;
}

.card-content {
    padding: 10px;
    overflow-x: auto;
}

.action-buttons {
    display: flex;
    gap: 5px;
}

.action-btn {
    padding: 8px;
    border: none;
    border-radius: 50%;
    cursor: pointer;
    color: #fff;
    font-size: 14px;
    display: flex;
    align-items: center;
    justify-content: center;
}

.edit-btn {
    background-color: #3498db;
}

.delete-btn {
    background-color: #e74c3c;
}

.add-btn {
    background-color: #0092d6;
    color: #fff;
    padding: 10px 15px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    display: flex;
    align-items: center;
    gap: 5px;
}

.add-btn svg {
    font-size: 14px;
}

.modal-backdrop {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.5);
    display: flex;
    justify-content: center;
    align-items: center;
    z-index: 1000;
}

.modal-content-default {
    background-color: #fff;
    border-radius: 8px;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
    position: relative;
    max-width: 700px;
    width: 90%;
    overflow-y: auto;
    display: flex;
    flex-direction: column;
}

.modal-content-wizard {
    background-color: #fff;
    border-radius: 8px;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
    position: relative;
    max-width: 900px;
    width: 90%;
    max-height: 90%;
    overflow-y: auto;
}

.modal-close-btn {
    position: absolute;
    top: 10px;
    right: 15px;
    font-size: 30px;
    border: none;
    background: transparent;
    cursor: pointer;
    color: #000;
    z-index: 1;
}

.modal-header {
    padding: 15px 20px;
    background-color: #0092d6;
    color: #eee;
}

.modal-header h2 {
    margin: 0;
}

.modal-body {
    padding: 20px;
}

.modal-footer {
    display: flex;
    justify-content: flex-end;
    padding: 10px;
    gap: 10px;
}

.modal-form-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 15px 20px;
}

.modal-form-grid .full-width {
    grid-column: 1 / -1;
}

.form-group {
    margin-bottom: 0;
}

.form-group label {
    display: block;
    font-weight: bold;
    margin-bottom: 5px;
    color: #555;
    font-size: 14px;
}

.form-group input,
.form-group select {
    width: 100%;
    padding: 10px;
    border: 1px solid #ddd;
    border-radius: 5px;
    box-sizing: border-box;
    background-color: #fff;
}

.form-group input:disabled {
    background-color: #f2f2f2;
}

.confirm-btn,
.cancel-btn {
    border-radius: 5px;
    padding: 10px 20px;
}

.confirm-btn {
    background-color: #3498db;
}

.cancel-btn {
    background-color: #6c757d;
}

.delete-btn.confirm-btn {
    background-color: #e74c3c;
}

.status-badge {
    padding: 4px 12px;
    border-radius: 15px;
    font-size: 12px;
    font-weight: bold;
    color: #fff;
    text-transform: capitalize;
}

.status-active {
    background-color: #28a745;
}

.status-inactive {
    background-color: #e74c3c;
}
</style>