<script lang="ts" setup>
import { ref } from 'vue';
import { useRouter } from 'vue-router'; // Importamos el router

// Credenciales de prueba
const VALID_PAYROLL = '1';
const VALID_PASSWORD = '1';
// RUTA ACTUALIZADA: Redirige a la vista de administración dentro del dashboard
const HOME_ROUTE = '/dashboard/admin';

// Estado del formulario
const payroll = ref('');
const password = ref('');
const loginError = ref(''); // Para mostrar errores de credenciales

// Inicializamos el router
const router = useRouter();

const handleLogin = () => {
  loginError.value = ''; // Limpiar errores anteriores

  // 1. Verificar credenciales
  if (payroll.value === VALID_PAYROLL && password.value === VALID_PASSWORD) {
    console.log('Login exitoso. Redirigiendo a:', HOME_ROUTE);
    
    // 2. Redirigir a la vista de administración
    void router.push(HOME_ROUTE); 

  } else {
    // 3. Mostrar mensaje de error si las credenciales son incorrectas
    loginError.value = 'Nómina o contraseña incorrecta. Por favor, inténtalo de nuevo.';
    console.error('Fallo en el intento de inicio de sesión.');
  }
};
</script>

<template>
  <div class="login-container">
    <div class="login-box">
      <h1 class="title">FA System</h1>
      <p class="subtitle">Facility Administration System</p>
      
      <form @submit.prevent="handleLogin">
        <!-- Mensaje de error (se muestra solo si hay un error) -->
        <div v-if="loginError" class="error-message">
          {{ loginError }}
        </div>

        <input v-model="payroll" type="text" placeholder="Nómina" required />
        <input v-model="password" type="password" placeholder="Contraseña" required />
        <button type="submit">INGRESAR</button>
        <p class="paragraph">
          ¿Olvidaste tu contraseña? Click
          <span><router-link to="/reset-password" class="reset-link">aquí</router-link></span>
          para restablecerla.
        </p>
      </form>
    </div>
  </div>
</template>

<style lang="scss" scoped>
.login-container {
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 100vh;
  background-color: #0f0f0f;
  background-size: cover;

  .login-box {
    background-color: rgba(255, 255, 255, 0.95);
    padding: 1.5rem;
    border-radius: 12px;
    box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);
    text-align: center;
    width: 100%;
    max-width: 450px;
    transition: all 0.3s ease;

    @media (max-width: 600px) {
      padding: 1.5rem;
      max-width: 0%;
    }

    .title {
      font-size: 2.5rem;
      font-weight: 700;
      color: #333;
      margin-bottom: 0.5rem;
    }

    .subtitle {
      font-size: 1.1rem;
      color: #777;
      margin-bottom: 2rem;
    }
    
    .error-message {
      background-color: #fdd;
      color: #d32f2f;
      padding: 10px;
      margin-bottom: 1rem;
      border-radius: 5px;
      border: 1px solid #f99;
      font-weight: 500;
    }

    input {
      display: block;
      width: 100%;
      padding: 0.75rem;
      margin-bottom: 1rem;
      border: 2px solid #89cff0;
      border-radius: 10px;
      transition: border-color 0.3s;
      
      &:focus {
        border-color: #d32f2f;
        outline: none;
        box-shadow: 0 0 0 3px rgba(211, 47, 47, 0.2);
      }
    }

    button {
      background-color: #d32f2f; /* Rojo de Quasar/Material Design */
      color: white;
      border: none;
      padding: 0.7rem;
      width: 100%;
      border-radius: 10px;
      font-weight: bold;
      cursor: pointer;
      transition: background-color 0.3s, transform 0.1s;
      text-transform: uppercase;
      letter-spacing: 0.05em;

      &:hover {
        background-color: #b71c1c; /* Rojo más oscuro al pasar el ratón */
      }
      
      &:active {
        transform: scale(0.99);
      }
    }

    .paragraph {
      font-size: 0.8rem;
      margin-top: 1.5rem;
      color: #555;
      
      .reset-link {
        color: #d32f2f;
        font-weight: 600;
        text-decoration: none;
        
        &:hover {
          text-decoration: underline;
        }
      }
    }
  }
}
</style>