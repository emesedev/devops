<template>
  <div class="sidebar" :class="{ 'collapsed': !isHovered && isCollapsed }" @mouseenter="handleMouseEnter"
    @mouseleave="handleMouseLeave">

    <div class="header">
      <h3 v-show="!isCollapsed || isHovered">FA System <span class="version">v1.0.0</span></h3>
      <button @click="toggleSidebar" class="toggle-btn-img">
        <font-awesome-icon :icon="['fas', 'bars']" /> 
      </button>
    </div>

    <div class="user-profile">
      <div class="user-info">
        <div class="avatar">
          <img src="https://i.pravatar.cc/150?img=56" alt="Chet Faker">
        </div>
        <span v-show="!isCollapsed || isHovered">Usuario</span>
      </div>
      <div class="notifications">
        <font-awesome-icon v-show="!isCollapsed || isHovered" :icon="['fas', 'bell']" class="notification-icon" />
        <span v-show="!isCollapsed || isHovered" class="notification-badge">{{ notificationCount }}</span>
      </div>
    </div>

    <ul class="menu">
      <li v-for="item in menuItems" :key="item.name" :class="{ 'has-submenu': item.submenu }">
        <router-link v-if="!item.submenu && item.route" :to="item.route" class="menu-item">
          <font-awesome-icon :icon="['fas', item.icon]" />
          <span v-show="!isCollapsed || isHovered">{{ item.name }}</span>
        </router-link>
        
        <div v-else @click="toggleSubmenu(item)" class="menu-item">
          <font-awesome-icon :icon="['fas', item.icon]" />
          <span v-show="!isCollapsed || isHovered">{{ item.name }}</span>
          
          <font-awesome-icon v-if="item.submenu && (!isCollapsed || isHovered)" class="chevron"
            :icon="['fas', item.isOpen ? 'chevron-up' : 'chevron-down']" />
        </div>
        
        <ul v-if="item.submenu && item.isOpen && (!isCollapsed || isHovered)" class="submenu">
          <li v-for="subitem in item.submenu" :key="subitem.name">
            <router-link :to="subitem.route" class="submenu-item">
              <font-awesome-icon :icon="['fas', subitem.icon]" />
              <span>{{ subitem.name }}</span>
            </router-link>
          </li>
        </ul>
      </li>
    </ul>

    <div class="sidebar-footer">
      <div @click="handleLogout" class="menu-item">
        <font-awesome-icon :icon="['fas', 'sign-out-alt']" />
        <span v-show="!isCollapsed || isHovered">Log out</span>
      </div>
    </div>
  </div>
</template>

<script lang="ts">
interface SubMenuItem {
  name: string;
  route: string;
  icon: string;
}

interface MenuItem {
  name: string;
  icon: string;
  route?: string;
  submenu?: SubMenuItem[];
  isOpen?: boolean;
}

export default {
  name: 'SidebarMenu',
  data() {
    return {
      isCollapsed: false,
      isHovered: false,
      notificationCount: 5,
      // Se mantiene la estructura de datos con solo nombres de íconos
      menuItems: [
        { name: 'Admin', icon: 'home', route: '/dashboard/admin' },
        { name: 'Dashboard', icon: 'chart-line', route: '/dashboard' },
        { name: 'Usuarios', icon: 'users', route: '/users' },
        { name: 'Equipos', icon: 'cogs', route: '/equipment' },

      ] as MenuItem[] 
    };
  },
  methods: {
    toggleSidebar() {
      this.isCollapsed = !this.isCollapsed;
      this.isHovered = false;
      this.menuItems.forEach((item: MenuItem) => { 
        if (item.submenu) {
          item.isOpen = false;
        }
      });
      this.$emit('toggle-sidebar', this.isCollapsed); 
    },
    toggleSubmenu(item: MenuItem) {
      if (item.submenu) {
        this.menuItems.forEach((menuItem: MenuItem) => {
          if (menuItem !== item && menuItem.submenu) {
            menuItem.isOpen = false;
          }
        });
        item.isOpen = !item.isOpen;
      }
    },
    handleMouseEnter() {
      if (this.isCollapsed) {
        this.isHovered = true;
      }
    },
    handleMouseLeave() {
      if (this.isCollapsed) {
        this.isHovered = false;
      }
    },
    handleLogout() {
      this.$emit('logout');
    }
  }
};
</script>

<style scoped>
.sidebar {
  width: 250px;
  background-color: #303030; /* Fondo principal oscuro */
  color: #ecf0f1; /* Texto blanco/claro */
  height: 100vh;
  position: fixed;
  top: 0;
  left: 0;
  transition: width 0.3s ease;
  overflow: hidden;
  display: flex;
  flex-direction: column;
  z-index: 100;
  border-right: 1px solid #89CFF0; /* Borde más oscuro */
}

.sidebar.collapsed {
  width: 60px;
}

/* 1. Encabezado */
.header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 15px;
  border-bottom: 1px solid #89CFF0; /* Borde separador oscuro */
  background-color: #303030; 
}

.header h3 {
  margin: 0;
  color: #fff;
  font-weight: 500;
  font-size: 1.2rem;
}

.version {
  color: #a0a0a0; /* Gris sutil */
  font-size: .6em;
  font-weight: 300;
}

.toggle-btn-img { 
  background: none;
  border: none;
  color: #fff;
  font-size: 1.5rem;
  cursor: pointer;
  padding: 0;
}

/* 2. Perfil de Usuario */
.user-profile {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 15px;
  border-bottom: 1px solid #89CFF0;
}

.user-profile .user-info {
  display: flex;
  align-items: center; 
}

.user-profile .avatar {
  width: 45px;
  height: 45px;
  border-radius: 50%;
  overflow: hidden;
  margin-right: 10px; 
  border: none; 
}

.user-profile span {
  font-weight: normal;
  color: #ecf0f1;
  font-size: 0.9em;
}

.notifications {
  position: relative;
}

.notification-icon {
  color: #ecf0f1;
  font-size: 0.9em;
}

.notification-badge {
  background-color: #e74c3c;
  color: #fff;
  border-radius: 50%;
  padding: 1px 5px; 
  font-size: 0.65rem;
  top: -6px;
  right: -6px;
}

/* 3. Menú Principal */
.menu {
  list-style: none;
  padding: 0;
  margin: 0;
  flex-grow: 1;
}

.menu-item {
  display: flex;
  align-items: center;
  padding: 10px 15px; 
  cursor: pointer;
  transition: background-color 0.1s ease;
  color: #c8c8c8; /* Color de texto gris claro para los ítems */
  text-decoration: none;
  font-size: 0.9em; 
}

.menu-item:hover {
  background-color: #4a4a4a; /* Fondo de hover ligeramente más claro */
  color: #ffffff; /* Texto blanco en hover */
}

/* Estilo para el componente de ícono de Font Awesome */
.menu-item svg { 
  font-size: 1.1em;
  width: 30px; 
  text-align: center;
  margin-right: 15px; 
  color: #89cff0; /* Color de acento para los íconos (azul/turquesa) */
}

.menu-item:hover svg {
  color: #ffffff; /* Icono blanco en hover */
}

.menu-item span {
  margin-left: 0; 
}

.chevron {
  margin-left: auto;
  font-size: 0.7em;
  color: #c8c8c8;
}

/* 4. Submenú */
.submenu {
  list-style: none;
  padding-left: 50px; 
  background-color: #3a3a3a; /* Fondo para submenú más oscuro que el principal */
}

.submenu-item {
  display: flex;
  align-items: center;
  padding: 8px 15px; 
  color: #a0a0a0; /* Texto gris más oscuro en submenú */
  font-size: 0.85em;
}

.submenu-item:hover {
  background-color: #4a4a4a;
  color: #ffffff;
}

/* Estilo para el ícono de submenú */
.submenu-item svg {
  width: 30px;
  text-align: center;
  margin-right: 15px;
  font-size: 0.8em;
  color: #a0a0a0;
}

/* 5. Pie de página */
.sidebar-footer {
  border-top: 1px solid #89CFF0;
  padding: 10px 0px;
}
</style>