<template>
    <div class="dashboard-container">
        <div class="kpi-section">
            <div class="kpi-card">
                <div class="kpi-content">
                    <i class="fas fa-tools icon-large"></i>
                    <div>
                        <span class="kpi-label">MP C1 & C2</span>
                        <span class="kpi-value">100%</span>
                    </div>
                </div>
                <div class="kpi-footer">
                    <span>Target 100%</span>
                </div>
            </div>

            <div class="kpi-card">
                <div class="kpi-content">
                    <i class="fas fa-tools icon-large"></i>
                    <div>
                        <span class="kpi-label">MP C3 & C4</span>
                        <span class="kpi-value">100%</span>
                    </div>
                </div>
                <div class="kpi-footer">
                    <span>Target > 85%</span>
                </div>
            </div>

            <div class="kpi-card">
                <div class="kpi-content">
                    <i class="fas fa-cogs icon-large"></i>
                    <div>
                        <span class="kpi-label">BM C1 & C2</span>
                        <span class="kpi-value">1000</span>
                    </div>
                </div>
                <div class="kpi-footer">
                    <span>Target 480 mins</span>
                </div>
            </div>

            <div class="kpi-card">
                <div class="kpi-content">
                    <i class="fas fa-cogs icon-large"></i>
                    <div>
                        <span class="kpi-label">BM C3 & C4</span>
                        <span class="kpi-value">100%</span>
                    </div>
                </div>
                <div class="kpi-footer">
                    <span>Target 10%</span>
                </div>
            </div>
        </div>

        <div class="charts-section">
            <div class="chart-card">
                <div class="chart-header">
                    <span class="chart-title">Mantenimiento Prevenivo</span>
                    <span class="chart-badge">+1.2%</span>
                </div>
                <apexchart type="bar" height="200" :options="chart1Options" :series="chart1Series"></apexchart>
                <div class="chart-footer">
                </div>
            </div>

            <div class="chart-card">
                <div class="chart-header">
                    <span class="chart-title">MTTR</span>
                    <span class="chart-badge yellow-bg">+20</span>
                </div>
                <apexchart type="line" height="200" :options="chart3Options" :series="chart3Series"></apexchart>
                <!--
                <div class="chart-footer">
                    <span>View more details</span>
                    <div class="chart-icon-footer yellow-bg"><i class="fas fa-info"></i></div>
                </div>
                -->
            </div>
        </div>
    </div>
</template>

<script lang="ts">
import VueApexCharts from 'vue3-apexcharts';
import type { ApexOptions } from 'apexcharts';

export default {
    name: 'AdminDashboard',
    components: {
        apexchart: VueApexCharts,
    },
    data() {
        return {
            chart1Series: [{
                name: 'Mantenimientos',
                data: [90, 100, 100, 97, 100, 0, 0, 0, 0, 0, 0, 0],
            }],
            chart1Options: {
                chart: {
                    type: 'bar' as const, 
                    toolbar: { show: true },
                    background: '#fff',
                },
                plotOptions: {
                    bar: {
                        horizontal: false,
                        columnWidth: '75%',
                        endingShape: 'flat',
                    },
                },
                dataLabels: { enabled: false },
                stroke: {
                    show: true,
                    width: 2,
                    colors: ['#388c00'],
                },
                xaxis: {
                    categories: ['Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec', 'Jan', 'Feb', 'Mar'],
                    labels: {
                        style: {
                            colors: '#6b7280',
                        },
                    },
                    axisBorder: { show: false },
                    axisTicks: { show: false },
                },
                yaxis: {
                    labels: {
                        style: {
                            colors: '#6b7280',
                        },
                    },
                },
                grid: {
                    show: true,
                    borderColor: '#e5e7eb',
                    strokeDashArray: 2,
                },
                tooltip: {
                    enabled: true,
                    theme: 'light',
                    style: {
                        fontSize: '12px',
                        fontFamily: 'Arial, sans-serif'
                    },
                    // *** INICIO DE CORRECCIÓN ***
                    // 1. Definir el formateador de título en la raíz del tooltip
                    title: {
                        // El valor de 'seriesName' aquí es el nombre de la categoría del eje X (si no se define x:formatter)
                        formatter: (seriesName: string) => seriesName + ':' 
                    },
                    // 2. Eliminar el bloque 'y' problemático si no se requiere formato especial
                    // Si se requiere un formato especial para el valor Y, se define así:
                    y: {
                        // 3. El formateador DEBE ser una función, no 'undefined'
                        formatter: function (val: number) {
                            // Dejamos que muestre el valor tal cual, o lo formateamos si es necesario.
                            // Aquí se usa 'val' sin modificar para evitar el error de 'undefined'.
                            return val.toString(); 
                        },
                    },
                    // *** FIN DE CORRECCIÓN ***
                },
                fill: {
                    type: 'gradient',
                    gradient: {
                        shade: 'light',
                        type: 'vertical',
                        shadeIntensity: 0.25,
                        gradientToColors: ['#c8e2b8'], 
                        inverseColors: true,
                        opacityFrom: 1,
                        opacityTo: 1,
                        stops: [0, 100],
                        colorStops: []
                    }
                },
                colors: ['#388c00'], 
            } as ApexOptions,

            chart3Series: [{
                name: 'MTTR',
                data: [115, 102, 64, 108, 88, 0, 0, 0, 0,]
            }],
            chart3Options: {
                chart: {
                    type: 'line' as const, 
                    toolbar: { show: true },
                    zoom: { enabled: false }
                },
                colors: ['#f59e0b'],
                stroke: { curve: 'smooth', width: 3 },
                markers: { size: 4 },
                grid: { show: true },
                xaxis: {
                    categories: ['Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec', 'Jan', 'Feb', 'Mar'],
                    labels: { show: true },
                    axisBorder: { show: true },
                    axisTicks: { show: true }
                },
                yaxis: {
                    labels: { show: true },
                    min: 0,
                    max: 120,
                },
                tooltip: { enabled: false }
            } as ApexOptions
        };
    }
};
</script>

<style scoped>
/* ... (Estilos CSS permanecen sin cambios) ... */
.dashboard-container {
    padding: 15px;
    font-family: Arial, sans-serif;
}

.kpi-section {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 20px;
    margin-bottom: 30px;
}

.kpi-card {
    min-width: 0;
    background-color: #fff;
    border-radius: 12px;
    padding: 20px;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.05);
    display: flex;
    flex-direction: column;
    color: #333;
    font-family: Arial, sans-serif;
    transition: transform 0.3s ease, box-shadow 0.3s ease;
    height: 100px;
}

.kpi-section::-webkit-scrollbar {
    height: 0;
}

.kpi-content {
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.kpi-label {
    display: block;
    font-size: 14px;
    color: #6b7280;
    text-align: right;
}

.kpi-value {
    display: block;
    font-size: 28px;
    font-weight: bold;
    text-align: right;
    color: #333;
}

.icon-large {
    font-size: 48px;
    color: #89cff0;
}

.kpi-footer {
    display: flex;
    align-items: center;
    font-size: 14px;
    color: #9ca3af;
    border-top: 1px solid #89cff0;
}

.icon-small {
    margin-right: 8px;
}

.charts-section {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 20px;
}

.chart-card {
    background-color: #fff;
    border-radius: 12px;
    padding: 20px;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.05);
    height: 300px;
}

.chart-header {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    margin-bottom: 15px;
}

.chart-title {
    font-size: 32px;
    font-weight: bold;
}

.chart-badge {
    font-size: 14px;
    color: #fff;
    padding: 4px 8px;
    border-radius: 9999px;
    background-color: #22c55e;
}

.red-bg {
    background-color: #ef4444;
}

.yellow-bg {
    background-color: #f59e0b;
}

.chart-footer {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-top: 15px;
    font-size: 14px;
    color: #6b7280;
}

.chart-icon-footer {
    width: 25px;
    height: 25px;
    border-radius: 50%;
    color: #fff;
    display: flex;
    align-items: center;
    justify-content: center;
}

.green-bg {
    background-color: #22c55e;
}

.orange-bg {
    background-color: #f59e0b;
}
</style>