<template>
    <div class="dashboard-container">
        <div class="dashboard-card table-card">
            <div class="card-header">
                <div class="header-content">
                    <font-awesome-icon :icon="['fas', 'tools']" class="header-icon" />
                    <span class="card-title">Mantenimiento Preventivo</span>
                </div>
            </div>
            <div class="card-content">
                <table>
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Nombre <i class="table-icon"></i></th>
                            <th>Localización <i class="table-icon"></i></th>
                            <th>Fecha <i class="table-icon"></i></th>
                            <th>Estatus <i class="table-icon"></i></th>
                            <th>Acción</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr v-for="(item, index) in tableData" :key="index">
                            <td>{{ index + 1 }}</td>
                            <td>{{ item.name }}</td>
                            <td>{{ item.location }}</td> <td>{{ item.date }}</td>     <td>{{ item.status }}</td>   <td class="action-buttons">
                                <button class="action-btn edit-btn">
                                    <font-awesome-icon :icon="['fas', 'edit']" />
                                </button>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="dashboard-card chart-card">
            <div class="card-header">
                <div class="header-content">
                    <span class="card-title">Mantenimiento Preventivo</span>
                </div>
            </div>
            <div class="card-content">
                <apexchart type="bar" height="300" :options="chartOptions" :series="chartSeries"></apexchart>
            </div>
        </div>
    </div>

    <div class="dashboard-container">
        <div class="dashboard-card table-card">
            <div class="card-header">
                <div class="header-content">
                    <font-awesome-icon :icon="['fas', 'tools']" class="header-icon2" />
                    <span class="card-title">Mantenimiento Correctivo</span>
                </div>
            </div>
            <div class="card-content">
                <table>
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Nombre</th>
                            <th>Hallazgo <i class="table-icon"></i></th>
                            <th>Fecha <i class="table-icon"></i></th>
                            <th>Estatus <i class="table-icon"></i></th>
                            <th>Acción</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr v-for="(item, index) in tableData" :key="index">
                            <td>{{ index + 1 }}</td>
                            <td>{{ item.name }}</td>
                            <td>{{ item.location }}</td> <td>{{ item.date }}</td>     <td>{{ item.status }}</td>   <td class="action-buttons">
                                <button class="action-btn do-btn">
                                    <font-awesome-icon :icon="['fas', 'edit']" />
                                </button>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="dashboard-card chart-card">
            <div class="card-header">
                <div class="header-content">
                    <span class="card-title">Mantenimiento Correctivo</span>
                </div>
            </div>
            <div class="card-content">
                <apexchart type="bar" height="300" :options="chartOptions2" :series="chartSeries2"></apexchart>
            </div>
        </div>
    </div>
</template>

<script lang="ts">
import { defineComponent } from 'vue';
import VueApexCharts from 'vue3-apexcharts';
import type { ApexOptions } from 'apexcharts'; // Importación clave para el tipado

export default defineComponent({
    name: 'PreventiveMaintDashboard',
    components: {
        apexchart: VueApexCharts,
    },
    data() {
        return {
            tableData: [
                { name: 'Cuarto Lobby', location: 'Planta', date: '2025-09-01', status: 'Retraso' },
                { name: 'Cortina Metalica 1', location: 'Eje 3I', date: '2025-09-01', status: 'Retraso' },
                { name: 'Cuarto Lab Metrologia', location: 'Pasillo Principal', date: '2025-09-01', status: 'Retraso' },
            ],
            chartSeries: [{
                name: 'Mantenimientos',
                data: [52, 20, 32],
            }],
            // ChartOptions 1
            chartOptions: {
                chart: {
                    type: 'bar',
                    height: 350,
                    toolbar: { show: true },
                    background: '#fff',
                },
                plotOptions: {
                    bar: {
                        horizontal: false,
                        columnWidth: '80%',
                        endingShape: 'flat',
                    },
                },
                dataLabels: { enabled: false },
                stroke: {
                    show: true,
                    width: 2,
                    colors: ['#388c00'],
                },
                xaxis: {
                    categories: ['Asignados', 'Terminados', 'Pendientes'],
                    labels: {
                        style: {
                            colors: '#6b7280',
                        },
                    },
                    axisBorder: { show: false },
                    axisTicks: { show: false },
                },
                yaxis: {
                    labels: {
                        style: {
                            colors: '#6b7280',
                        },
                    },
                },
                grid: {
                    show: true,
                    borderColor: '#e5e7eb',
                    strokeDashArray: 2,
                },
                tooltip: {
                    enabled: true,
                    theme: 'light',
                    style: {
                        fontSize: '12px',
                        fontFamily: 'Arial, sans-serif'
                    },
                    y: {
                        // 🟢 CORRECCIÓN 1: Eliminada la línea 'formatter: undefined,'
                        title: {
                            formatter: (seriesName) => seriesName + ':'
                        }
                    }
                },
                fill: {
                    type: 'gradient',
                    gradient: {
                        shade: 'light',
                        type: 'vertical',
                        shadeIntensity: 0.25,
                        gradientToColors: ['#c8e2b8'],
                        inverseColors: true,
                        opacityFrom: 1,
                        opacityTo: 1,
                        stops: [0, 100],
                        colorStops: []
                    }
                },
                colors: ['#388c00'],
            } as ApexOptions,
            
            chartSeries2: [{
                name: 'Mantenimientos',
                data: [52, 20, 32],
            }],
            // ChartOptions 2
            chartOptions2: {
                chart: {
                    type: 'bar',
                    height: 350,
                    toolbar: { show: true },
                    background: '#fff',
                },
                plotOptions: {
                    bar: {
                        horizontal: false,
                        columnWidth: '80%',
                        endingShape: 'flat',
                    },
                },
                dataLabels: { enabled: false },
                stroke: {
                    show: true,
                    width: 2,
                    colors: ['#4e84e5', '#388c00', '#bf9400'],
                },
                xaxis: {
                    categories: ['Asignados', 'Terminados', 'Pendientes'],
                    labels: {
                        style: {
                            colors: '#6b7280',
                        },
                    },
                    axisBorder: { show: false },
                    axisTicks: { show: false },
                },
                yaxis: {
                    labels: {
                        style: {
                            colors: '#6b7280',
                        },
                    },
                },
                grid: {
                    show: true,
                    borderColor: '#e5e7eb',
                    strokeDashArray: 2,
                },
                tooltip: {
                    enabled: true,
                    theme: 'light',
                    style: {
                        fontSize: '12px',
                        fontFamily: 'Arial, sans-serif'
                    },
                    y: {
                        // 🟢 CORRECCIÓN 2: Eliminada la línea 'formatter: undefined,'
                        title: {
                            formatter: (seriesName) => seriesName + ':'
                        }
                    }
                },
                fill: {
                    type: 'gradient',
                    gradient: {
                        shade: 'light',
                        type: 'vertical',
                        shadeIntensity: 0.25,
                        gradientToColors: ['#f2f5fc', '#c8e2b8', '#ffe8a0'],
                        inverseColors: true,
                        opacityFrom: 1,
                        opacityTo: 1,
                        stops: [0, 100],
                        colorStops: []
                    }
                },
                colors: ['#4e84e5', '#388c00', '#bf9400'],
            } as ApexOptions,
            
        };
    },
});
</script>

<style scoped>
.dashboard-container {
    display: flex;
    gap: 20px;
    padding: 15px;
    padding-bottom: 15px;
}

.dashboard-card {
    background-color: #fff;
    border-radius: 10px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    overflow: hidden;
    flex: 1;
    height: 350px;
}

.card-header {
    background-color: #fff;
    color: #000;
    padding: 10px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    border-bottom: 1px solid #ddd;
    border-color: #000;
}

.header-content {
    display: flex;
    align-items: center;
    gap: 10px;
}

/* Estilos para el componente de ícono (Font Awesome) */
.header-icon {
    font-size: 20px;
    color: #2ecc71; /* Verde */
    background-color: #e8f5e9;
    padding: 10px;
    border-radius: 5px;
}

/* Estilos para el segundo ícono (Mantenimiento Correctivo) */
.header-icon2 {
    font-size: 20px;
    color: #2eaccc; /* Azul/Cian */
    background-color: #e8f5e9;
    padding: 10px;
    border-radius: 5px;
}

.settings-icon {
    font-size: 20px;
    color: #888;
    cursor: pointer;
}

.card-title {
    font-weight: bold;
    color: #303030;
}

.card-content {
    padding: 10px;
}

.table-card {
    min-width: 65%;
}

table {
    width: 100%;
    border-collapse: collapse;
}

th,
td {
    padding: 15px;
    text-align: left;
    border-bottom: 1px solid #ddd;
    color: #6b7280;
}

th {
    font-weight: bold;
    text-transform: uppercase;
    font-size: 14px;
    color: #000;
}

thead tr {
    background-color: #fff;
}

tbody tr:hover {
    background-color: #f9f9f9;
}

.action-btn {
    padding: 8px;
    border: none;
    border-radius: 50%;
    cursor: pointer;
    color: #fff;
    font-size: 14px;
    display: flex;
    align-items: center;
    justify-content: center;
}

.edit-btn {
    background-color: #2ecc71; /* Verde */
}

.do-btn {
    background-color: #2eaccc; /* Azul/Cian */
}
</style>