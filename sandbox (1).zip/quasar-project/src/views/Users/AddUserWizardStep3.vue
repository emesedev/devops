<template>
  <div>
    <h3 class="step-title">¿Cuál es el rol del usuario?</h3>

    <div class="checkbox-options">
      <div :class="['option-card', { active: selectedRole === 'technician' }]" @click="selectedRole = 'technician'">
        <div class="icon-circle">
          <font-awesome-icon :icon="['fas', 'tools']" />
        </div>
        <span class="option-label">Técnico</span>
      </div>

      <div :class="['option-card', { active: selectedRole === 'team-leader' }]" @click="selectedRole = 'team-leader'">
        <div class="icon-circle">
          <font-awesome-icon :icon="['fas', 'laptop-file']" />
        </div>
        <span class="option-label">Líder de equipo</span>
      </div>

      <div :class="['option-card', { active: selectedRole === 'supervisor' }]" @click="selectedRole = 'supervisor'">
        <div class="icon-circle">
          <font-awesome-icon :icon="['fas', 'chart-line']" />
        </div>
        <span class="option-label">Supervisor</span>
      </div>

      <div :class="['option-card', { active: selectedRole === 'admin' }]" @click="selectedRole = 'admin'">
        <div class="icon-circle">
          <font-awesome-icon :icon="['fas', 'laptop-code']" />
        </div>
        <span class="option-label">Administrador</span>
      </div>
    </div>

    <div class="navigation-buttons">
      <button class="nav-btn prev-btn" @click="$emit('prev-step')">ANTERIOR</button>
      <button :disabled="!selectedRole" :class="['nav-btn', 'next-btn', { 'btn-disabled': !selectedRole }]"
        @click="handleNext">
        TERMINAR
      </button>
    </div>
  </div>
</template>

<script lang="ts">
import { defineComponent, type PropType } from 'vue';

// Define los tipos de roles permitidos para mayor tipificación
type RoleType = 'technician' | 'team-leader' | 'supervisor' | 'admin' | null;

// Define la estructura para el tipado de TypeScript
interface FormDataStructure {
  role: RoleType; // Usamos el tipo definido
  [key: string]: unknown; // Resuelve el error de 'any'
}

export default defineComponent({
  name: 'Step2Wizard',
  props: {
    // Recibe formData del componente padre
    formData: {
      type: Object as PropType<FormDataStructure>,
      required: true,
    },
  },
  // Declaración de eventos para comunicación con el padre
  emits: ['update:formData', 'prev-step', 'next-step'],

  computed: {
    /**
    * Propiedad computada que actúa como v-model local para 'role'.
    */
    selectedRole: {
      get(): RoleType {
        return this.formData.role; // CORREGIDO: Eliminada la aserción de tipo redundante
      },
      set(newRole: RoleType) {
        this.updateField('role', newRole);
      }
    }
  },

  methods: {
    /**
    * Clona el objeto formData, actualiza el campo y emite el objeto actualizado.
       * Se usa 'unknown' para el valor.
    */
    updateField(fieldName: keyof FormDataStructure, value: unknown): void {
      const newFormData = { ...this.formData };
      newFormData[fieldName] = value;
      this.$emit('update:formData', newFormData);
    },

    /**
    * Maneja el evento 'next-step', validando que un rol haya sido seleccionado.
    */
    handleNext(): void {
      if (this.selectedRole) {
        this.$emit('next-step');
      } else {
        console.error('Debe seleccionar un rol antes de continuar.');
      }
    }
  },
});
</script>

<style scoped>
/* Estilos */
.btn-disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.step-title {
  text-align: center;
  font-size: 18px;
  color: #252525;
  margin-bottom: 30px;
  font-weight: normal;
}

.checkbox-options {
  display: flex;
  justify-content: center;
  gap: 30px;
  margin-bottom: 50px;
}

.option-card {
  display: flex;
  flex-direction: column;
  align-items: center;
  cursor: pointer;
  padding: 15px;
  border-radius: 8px;
  transition: all 0.3s ease;
  min-width: 120px;
  border: 1px solid transparent;
}

.option-card.active {
  background-color: #f0fdf4;
  border: 1px solid #0092d6;
}

.icon-circle {
  width: 100px;
  height: 100px;
  border: 2px solid #ccc;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 32px;
  color: #999;
  transition: all 0.3s ease;
}

.option-card.active .icon-circle {
  border-color: #0092d6;
  color: #0092d6;
}

.option-card:hover {
  background-color: #f0fdf4;
}

.option-card:hover .icon-circle {
  border-color: #0092d6;
  color: #0092d6;
}

.option-card:hover .option-label {
  color: #0092d6;
}

.option-label {
  margin-top: 10px;
  font-size: 14px;
  color: #252525;
}

.option-card.active .option-label {
  color: #0092d6;
}

.navigation-buttons {
  display: flex;
  justify-content: space-between;
}

.nav-btn {
  padding: 10px 25px;
  border: none;
  border-radius: 5px;
  font-weight: bold;
  cursor: pointer;
  transition: background-color 0.3s ease;
}

.prev-btn {
  background-color: #a0a0a0;
  color: #fff;
}

.next-btn {
  background-color: #0092d6;
  color: #fff;
}
</style>