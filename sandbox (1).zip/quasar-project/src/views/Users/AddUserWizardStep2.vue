<template>
  <div>
    <h3 class="step-title">Selecciona la información del usuario</h3>
    <div class="input-group">
      <div class="input-field select-field">
        <select :value="formData.department"
          @change="updateField('department', ($event.target as HTMLSelectElement).value)">
          <option value="" disabled selected>Departamento</option>
          <option v-for="department in departments" :key="department" :value="department">
            {{ department }}
          </option>
        </select>
        <font-awesome-icon :icon="['fas', 'chevron-down']" class="select-arrow" />
      </div>
      <div class="input-field select-field">
        <select :value="formData.position"
          @change="updateField('position', ($event.target as HTMLSelectElement).value)">
          <option value="" disabled selected>Posición</option>
          <option v-for="position in positions" :key="position" :value="position">
            {{ position }}
          </option>
        </select>
        <font-awesome-icon :icon="['fas', 'chevron-down']" class="select-arrow" />
      </div>

      <div class="input-field select-field">
        <select :value="formData.area" @change="updateField('area', ($event.target as HTMLSelectElement).value)">          
          <option value="" disabled selected>Área</option>
          <option v-for="area in areas" :key="area" :value="area">{{ area }}</option>
        </select>
        <font-awesome-icon :icon="['fas', 'chevron-down']" class="select-arrow" />
      </div>
    </div>

    <div class="navigation-buttons">
      <button class="nav-btn prev-btn" @click="$emit('prev-step')">ANTERIOR</button>
      <button class="nav-btn next-btn" @click="$emit('next-step')" :disabled="!isStepValid">
        SIGUIENTE
      </button>
    </div>
  </div>
</template>

<script lang="ts">
// Corrección: 'computed' no se importa aquí si solo se usa como propiedad de Options API.
import { defineComponent, type PropType } from 'vue';

// Define la estructura de los campos que maneja este paso
interface Step2FormData {
  department: string;
  position: string;
  area: string;
}

// Define la estructura para el tipado de los datos locales (data)
interface ComponentData {
  departments: string[];
  positions: string[];
  areas: string[];
}

export default defineComponent({
  name: 'AddUserWizardStep2',
  props: {
    // Tipado de la prop formData
    formData: {
      type: Object as PropType<Step2FormData>,
      required: true,
    },
  },
  // Declaración de eventos que el componente emite
  emits: ['update:formData', 'prev-step', 'next-step'],
  data(): ComponentData {
    return {
      departments: ['Facility SPP', 'Facility IPP'],
      positions: [
        'Analyst',
        'Specialist',
        'Team Leader',
        'Advanced Specialist',
        'Supervisor',
        'Assistant Manager',
        'Manager',
      ],
      areas: ['Mechanics', 'Electrical', 'General services', 'Planning', 'Plant engineering'],
    };
  },
  // Lógica computada para la validación del paso
  computed: {
    isStepValid(): boolean {
      // Verifica que los tres campos tengan un valor (no vacío).
      return (
        !!this.formData.department.trim() &&
        !!this.formData.position.trim() &&
        !!this.formData.area.trim()
      );
    },
  },
  methods: {
    /**
     * Maneja la actualización de cualquier campo de selección y emite el cambio.
     */
    updateField(fieldName: keyof Step2FormData, value: string): void {
      const newFormData = { ...this.formData };

      newFormData[fieldName] = value;

      this.$emit('update:formData', newFormData);
    },
  },
});
</script>

<style scoped>
/* --- Estilos --- */
.step-title {
  text-align: center;
  font-size: 18px;
  color: #252525;
  margin-bottom: 30px;
  font-weight: normal;
}

.input-group {
  display: flex;
  flex-wrap: wrap;
  gap: 20px;
  margin-bottom: 50px;
}

.input-field {
  /* Cálculo para que quepan 3 elementos */
  flex: 1 1 calc(33.33% - 14px);
  position: relative;
}

.input-field.select-field {
  position: relative;
}

select {
  width: 100%;
  padding: 12px;
  border: 1px solid #ddd;
  border-radius: 5px;
  font-size: 16px;
  outline: none;
  box-sizing: border-box;
  /* Reset para quitar el estilo nativo del select */
  -webkit-appearance: none;
  -moz-appearance: none;
  appearance: none;
  cursor: pointer;
  background-color: #fff;
  color: #707070;
  transition: border-color 0.3s;
}

/* Estilos para placeholder/opción deshabilitada */
select option[value='']:disabled {
  color: #999;
}

/* Estilos para opciones válidas */
select option:not([value='']) {
  color: #252525;
}

.select-arrow {
  position: absolute;
  right: 15px;
  top: 50%;
  transform: translateY(-50%);
  color: #999;
  pointer-events: none;
  /* Asegura que el clic pase al select */
  font-size: 14px;
}

.select-field select:focus {
  border-color: #0092d6;
}

.navigation-buttons {
  display: flex;
  justify-content: space-between;
}

.nav-btn {
  padding: 10px 25px;
  border: none;
  border-radius: 5px;
  font-weight: bold;
  cursor: pointer;
  transition: background-color 0.3s ease;
}

.prev-btn {
  background-color: #a0a0a0;
  color: #fff;
}

.prev-btn:hover {
  background-color: #8c8c8c;
}

.next-btn {
  background-color: #0092d6;
  color: #fff;
}

.next-btn:hover:not(:disabled) {
  background-color: #0079b3;
}

/* Estilo para el botón deshabilitado */
.nav-btn:disabled {
  background-color: #cccccc;
  cursor: not-allowed;
  opacity: 0.6;
}
</style>
