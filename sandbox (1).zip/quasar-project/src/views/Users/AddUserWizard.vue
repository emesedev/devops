<template>
    <div class="wizard-container">
       <div class="header-steps">
          <div      :class="['step-item', { active: currentStep === 1 }]"      @click="goToStep(1)">
             PASO 1
            </div>
          <div      :class="['step-item', { active: currentStep === 2 }]"      @click="goToStep(2)">
             PASO 2
            </div>
          <div      :class="['step-item', { active: currentStep === 3 }]"      @click="goToStep(3)">
             PASO 3
            </div>
         </div>
    
       <div class="wizard-body">
          <component      :is="currentStepComponent" v-model:form-data="formData"     
        @next-step="nextStep"      @prev-step="prevStep"      @finish-wizard="finishWizard">
            </component>
         </div>
      </div>
   </template>

<script lang="ts">
import { defineComponent } from 'vue';

// SOLUCIÓN MÁS ROBUSTA: Usar el alias @/ que apunta a la carpeta /src
import Step1 from './AddUserWizardStep1.vue';
import Step2 from './AddUserWizardStep2.vue';
import Step3 from './AddUserWizardStep3.vue';

// --- Tipado ---
type RoleType = 'technician' | 'team-leader' | 'supervisor' | 'admin' | null;

interface FormDataStructure {
  firstName: string;
  lastName: string;
  email: string;
  role: RoleType;
  occupation: unknown[];
  streetName: string;
  streetNumber: string;
  city: string;
  country: string;
  [key: string]: unknown;
}

interface ComponentData {
  currentStep: number;
  formData: FormDataStructure;
}
// --- Fin Tipado ---

export default defineComponent({
  name: 'AddUserWizard',
  components: {
    Step1,
    Step2,
    Step3
  },
  emits: ['finish-wizard'],

  data(): ComponentData {
    return {
      currentStep: 1,
      formData: {
        firstName: '',
        lastName: '',
        email: '',
        role: null,
        occupation: [],
        streetName: '',
        streetNumber: '',
        city: '',
        country: ''
      } as FormDataStructure
    };
  },
  computed: {
    currentStepComponent(): string {
      switch (this.currentStep) {
        case 1:
          return 'Step1';
        case 2:
          return 'Step2';
        case 3:
          return 'Step3';
        default:
          return 'Step1';
      }
    }
  },
  methods: {
    nextStep(): void {
      if (this.currentStep < 3) {
        this.currentStep++;
      }
    },
    prevStep(): void {
      if (this.currentStep > 1) {
        this.currentStep--;
      }
    },
    goToStep(step: number): void {
      if (step >= 1 && step <= 3) {
        this.currentStep = step;
      }
    },
    finishWizard(): void {
      console.log('Wizard finished! Data:', this.formData);
      alert('¡Perfil creado exitosamente!');
      this.$emit('finish-wizard', this.formData);
    }
  }
});
</script>

<style scoped>
/* --- Estilos --- */
.wizard-container {
  max-width: 800px;
  margin: 50px auto;
  background-color: #fff;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
  overflow: hidden;
}

.header-steps {
  display: flex;
  justify-content: space-between;
  border-bottom: 1px solid #e0e0e0;
}

.step-item {
  flex: 1;
  text-align: center;
  padding: 15px;
  cursor: pointer;
  background-color: #f5f5f5;
  color: #000;
  transition: all 0.5s ease;
  font-weight: bold;
}

.step-item.active {
  background-color: #0092d6;
  color: #fff;
}

.wizard-body {
  padding: 20px;
}
</style>