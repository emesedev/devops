<template>
    <div class="dashboard-container">
        <div class="dashboard-card table-card">
            <div class="card-header">
                <div class="header-content">
                    <font-awesome-icon :icon="['fas', 'user']" class="header-icon" />
                    <span class="card-title">Usuarios</span>
                </div>
                <div class="header-actions">
                    <button class="add-btn" @click="openWizardModal">
                        <font-awesome-icon :icon="['fas', 'plus']" />
                        Agregar Usuario
                    </button>
                </div>
            </div>
            <div class="card-content">
                <table>
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Nombre</th>
                            <th>Área</th>
                            <th>Puesto</th>
                            <th>Estatus</th>
                            <th>Acción</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr v-for="item in tableData" :key="item.id">
                            <td>{{ item.id }}</td>
                            <td>{{ item.name }} {{ item.father_lastname }}</td>
                            <td>{{ item.area }}</td>
                            <td>{{ item.position }}</td>
                            <td>
                                <span :class="['status-badge', getStatusClass(item.status)]">{{
                                    item.status }}</span>
                            </td>
                            <td class="action-buttons">
                                <button class="action-btn edit-btn" @click="openModal('edit', item)">
                                    <font-awesome-icon :icon="['fas', 'edit']" />
                                </button>
                                <button class="action-btn delete-btn" @click="openModal('delete', item)">
                                    <font-awesome-icon :icon="['fas', 'trash-alt']" />
                                </button>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>

        <div class="modal-backdrop" v-if="isWizardVisible" @click="closeWizardModal">
            <div class="modal-content-wizard" @click.stop>
                <button class="modal-close-btn" @click="closeWizardModal">&times;</button>
                <Wizard @finish-wizard="closeWizardModal" />
            </div>
        </div>

        <div class="modal-backdrop" v-if="isModalVisible" @click="closeModal">
            <div class="modal-content-default" @click.stop>
                <button class="modal-close-btn" @click="closeModal">&times;</button>
                <div class="modal-header">
                    <h2>{{ modalTitle }}</h2>
                </div>
                <div class="modal-body">
                    <form v-if="modalAction === 'edit' && selectedItem" @submit.prevent="handleAction"
                        class="modal-form">
                        <div class="modal-form-grid">
                            <div class="form-group">
                                <label>ID:</label>
                                <input type="text" v-model="selectedItem.id" disabled>
                            </div>
                            <div class="form-group">
                                <label>Nombre(s):</label>
                                <input type="text" v-model="selectedItem.name" required>
                            </div>
                            <div class="form-group">
                                <label>Apellido Paterno:</label>
                                <input type="text" v-model="selectedItem.father_lastname" required>
                            </div>
                            <div class="form-group">
                                <label>Apellido Materno:</label>
                                <input type="text" v-model="selectedItem.mother_lastname">
                            </div>
                            <div class="form-group">
                                <label>Contraseña:</label>
                                <input type="password" v-model="selectedItem.password"
                                    placeholder="Dejar vacío para no cambiar">
                            </div>
                            <div class="form-group">
                                <label>Posición (Puesto):</label>
                                <select v-model="selectedItem.position">
                                    <option v-for="pos in positions" :key="pos" :value="pos">{{ pos
                                    }}</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Área:</label>
                                <select v-model="selectedItem.area">
                                    <option v-for="ar in areas" :key="ar" :value="ar">{{ ar }}
                                    </option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Departamento:</label>
                                <select v-model="selectedItem.department">
                                    <option v-for="dep in departments" :key="dep" :value="dep">{{
                                        dep }}</option>
                                </select>
                            </div>
                            <div class="form-group full-width">
                                <label>Email:</label>
                                <input type="email" v-model="selectedItem.email" required>
                            </div>
                            <div class="form-group">
                                <label>Planta:</label>
                                <select v-model="selectedItem.plant">
                                    <option v-for="pl in plants" :key="pl" :value="pl">{{ pl }}
                                    </option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Estatus:</label>
                                <select v-model="selectedItem.status">
                                    <option value="Active">Activo</option>
                                    <option value="Inactive">Inactivo</option>
                                </select>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="action-btn cancel-btn" @click="closeModal">Cancelar</button>
                            <button type="submit" class="action-btn confirm-btn">Guardar</button>
                        </div>
                    </form>
                    <p v-else-if="modalAction === 'delete' && selectedItem">¿Estás seguro que
                        quieres eliminar a **{{ selectedItem?.name }} {{ selectedItem?.father_lastname }}**?</p>
                </div>
                <div class="modal-footer" v-if="modalAction === 'delete' && selectedItem">
                    <button type="button" class="action-btn cancel-btn" @click="closeModal">Cancelar</button>
                    <button class="action-btn delete-btn confirm-btn" @click="handleAction">Confirmar</button>
                </div>
            </div>
        </div>
    </div>
</template>

<script lang="ts">
import { defineComponent } from 'vue';
import Wizard from './AddUserWizard.vue';

interface User {
    id: number;
    name: string;
    father_lastname: string;
    mother_lastname: string;
    password: string;
    position: string;
    area: string;
    department: string;
    email: string;
    plant: string;
    status: 'Active' | 'Inactive';
}

interface ComponentData {
    isWizardVisible: boolean;
    isModalVisible: boolean;
    modalAction: 'edit' | 'delete' | '';
    modalTitle: string;
    selectedItem: User | null;
    positions: string[];
    areas: string[];
    departments: string[];
    plants: string[];
    tableData: User[];
}

export default defineComponent({
    components: {
        Wizard
    },
    data(): ComponentData {
        return {
            isWizardVisible: false,
            isModalVisible: false,
            modalAction: '',
            modalTitle: '',
            selectedItem: null,

            positions: ['Specialist', 'Advanced Specialist', 'Team Leader', 'Supervisor', 'Manager', 'Engineer'],
            areas: ['Planning', 'Plant Engineering', 'Mechanics', 'Electrical', 'Generala Services', 'Maintenance'],
            departments: ['Facility SPP', 'Facility IPP', 'Engineering', 'Maintenance'],
            plants: ['DENSO Mexico', 'DENSO Japan', 'DENSO USA'],

            // CORREGIDO: Todos los elementos tienen la propiedad 'email'
            tableData: [
                {
                    id: 1,
                    name: 'Moises',
                    father_lastname: 'Santos',
                    mother_lastname: 'Leon',
                    password: 'hashed_password_1',
                    position: 'Specialist',
                    area: 'Planning',
                    department: 'Facility SPP',
                    email: 'moises.santos@na.denso.com',
                    plant: 'DENSO Mexico',
                    status: 'Active'
                },
                {
                    id: 2,
                    name: 'Ana',
                    father_lastname: 'Vazquez',
                    mother_lastname: 'Venegas',
                    password: 'hashed_password_2',
                    position: 'Advanced Specialist',
                    area: 'Planning',
                    department: 'Engineering',
                    email: 'ana.vazquez@na.denso.com',
                    plant: 'DENSO Mexico',
                    status: 'Active'
                },
                {
                    id: 3,
                    name: 'Juan',
                    father_lastname: 'Perez',
                    mother_lastname: '',
                    password: 'hashed_password_3',
                    position: 'Engineer',
                    area: 'Maintenance',
                    department: 'Maintenance',
                    email: 'juan.perez@na.denso.com',
                    plant: 'DENSO Mexico',
                    status: 'Inactive'
                },
            ],
        };
    },
    methods: {
        openWizardModal(): void {
            this.isWizardVisible = true;
        },
        closeWizardModal(): void {
            this.isWizardVisible = false;
        },
        openModal(action: 'edit' | 'delete', item: User): void {
            this.modalAction = action;
            // Clonamos el objeto para evitar la mutación de tableData original
            this.selectedItem = JSON.parse(JSON.stringify(item)) as User;

            if (action === 'edit') {
                this.modalTitle = 'Editar Usuario';
            } else if (action === 'delete') {
                this.modalTitle = 'Eliminar Usuario';
            }
            this.isModalVisible = true;
        },
        closeModal(): void {
            this.isModalVisible = false;
            this.selectedItem = null;
        },
        handleAction(): void {
            if (!this.selectedItem) return;

            if (this.modalAction === 'edit') {
                const index = this.tableData.findIndex(item => item.id === this.selectedItem!.id);

                if (index !== -1) {
                    const originalItem = this.tableData[index];
                    // Mantener la contraseña anterior si el campo 'password' está vacío
                    if (originalItem && originalItem.password && (!this.selectedItem.password || this.selectedItem.password === '')) {
                        this.selectedItem.password = originalItem.password;
                    }
                    // Reemplazar el elemento existente con el editado
                    this.tableData.splice(index, 1, this.selectedItem);
                }
            } else if (this.modalAction === 'delete') {
                // Filtrar el elemento a eliminar
                this.tableData = this.tableData.filter(item => item.id !== this.selectedItem!.id);
            }
            this.closeModal();
        },
        getStatusClass(status: 'Active' | 'Inactive'): string {
            const statusMap: Record<User['status'], string> = {
                Active: 'status-active',
                Inactive: 'status-inactive',
            };
            return statusMap[status] || '';
        }
    },
});
</script>

<style scoped>
/* --- Estilos --- */
/* (Se mantienen los estilos originales para integridad del componente) */
.dashboard-container {
    display: flex;
    gap: 10px;
    padding: 15px;
}

.dashboard-card {
    background-color: #fff;
    border-radius: 10px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    overflow: hidden;
    flex: 1;
}

table {
    width: 100%;
    border-collapse: collapse;
}

th,
td {
    padding: 15px;
    text-align: left;
    border-bottom: 1px solid #ddd;
    color: #6b7280;
}

th {
    font-weight: bold;
    text-transform: uppercase;
    font-size: 14px;
    color: #000;
}

thead tr {
    background-color: #fff;
}

tbody tr:hover {
    background-color: #f9f9f9;
}

.card-header {
    background-color: #fff;
    color: #000;
    padding: 10px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    border-bottom: 1px solid #ddd;
    border-color: #000;
}

.header-content {
    display: flex;
    align-items: center;
    gap: 15px;
}

.header-actions {
    display: flex;
    align-items: center;
}

.header-icon {
    font-size: 30px;
    color: #0092d6;
    background-color: #e8f5e9;
    padding: 10px;
    border-radius: 5px;
}

.card-title {
    font-weight: bold;
    color: #444;
}

.card-content {
    padding: 10px;
    overflow-x: auto;
}

.action-buttons {
    display: flex;
    gap: 5px;
}

.action-btn {
    padding: 8px;
    border: none;
    border-radius: 50%;
    cursor: pointer;
    color: #fff;
    font-size: 14px;
    display: flex;
    align-items: center;
    justify-content: center;
}

.edit-btn {
    background-color: #3498db;
}

.delete-btn {
    background-color: #e74c3c;
}

.add-btn {
    background-color: #0092d6;
    color: #fff;
    padding: 10px 15px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    display: flex;
    align-items: center;
    gap: 5px;
}

.add-btn svg {
    font-size: 14px;
}

.modal-backdrop {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.5);
    display: flex;
    justify-content: center;
    align-items: center;
    z-index: 1000;
}

.modal-content-default {
    background-color: #fff;
    border-radius: 8px;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
    position: relative;
    max-width: 700px;
    width: 90%;
    overflow-y: auto;
    display: flex;
    flex-direction: column;
}

.modal-content-wizard {
    background-color: #fff;
    border-radius: 8px;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
    position: relative;
    max-width: 900px;
    width: 90%;
    max-height: 90%;
    overflow-y: auto;
}

.modal-close-btn {
    position: absolute;
    top: 10px;
    right: 15px;
    font-size: 30px;
    border: none;
    background: transparent;
    cursor: pointer;
    color: #000;
    z-index: 1;
}

.modal-header {
    padding: 15px 20px;
    background-color: #0092d6;
    color: #eee;
}

.modal-header h2 {
    margin: 0;
}

.modal-body {
    padding: 20px;
}

.modal-footer {
    display: flex;
    justify-content: flex-end;
    padding: 10px;
    gap: 10px;
}

.modal-form-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 15px 20px;
}

.modal-form-grid .full-width {
    grid-column: 1 / -1;
}

.form-group {
    margin-bottom: 0;
}

.form-group label {
    display: block;
    font-weight: bold;
    margin-bottom: 5px;
    color: #555;
    font-size: 14px;
}

.form-group input,
.form-group select {
    width: 100%;
    padding: 10px;
    border: 1px solid #ddd;
    border-radius: 5px;
    box-sizing: border-box;
    background-color: #fff;
}

.form-group input:disabled {
    background-color: #f2f2f2;
}

.confirm-btn,
.cancel-btn {
    border-radius: 5px;
    padding: 10px 20px;
}

.confirm-btn {
    background-color: #3498db;
}

.cancel-btn {
    background-color: #6c757d;
}

.delete-btn.confirm-btn {
    background-color: #e74c3c;
}

.status-badge {
    padding: 4px 12px;
    border-radius: 15px;
    font-size: 12px;
    font-weight: bold;
    color: #fff;
    text-transform: capitalize;
}

.status-active {
    background-color: #28a745;
}

.status-inactive {
    background-color: #e74c3c;
}
</style>