<template>
    <div>
        <h3 class="step-title">Información principal</h3>

        <div class="form-section">
            <div class="profile-picture">
                <div class="image-placeholder" @click="openFilePicker">
                    <img v-if="previewImage" :src="previewImage" alt="Profile Picture" class="profile-image">
                    <font-awesome-icon v-else :icon="['fas', 'user-circle']" />
                </div>
                <span class="choose-text" @click="openFilePicker">SELECCIONA UNA IMAGEN</span>
                <input type="file" ref="fileInput" @change="handleFileChange" accept="image/*"
                    class="hidden-file-input">
            </div>

            <div class="input-group">
                <div class="input-field">
                    <font-awesome-icon :icon="['fas', 'user-tag']" />
                    <input type="text" placeholder="Nombre" :value="formData.firstName"
                        @input="updateField('firstName', ($event.target as HTMLInputElement).value)">
                </div>
                <div class="input-field">
                    <font-awesome-icon :icon="['fas', 'user-tag']" />
                    <input type="text" placeholder="Apellidos" :value="formData.lastName"
                        @input="updateField('lastName', ($event.target as HTMLInputElement).value)">
                </div>
            </div>

            <div class="input-field full-width">
                <font-awesome-icon :icon="['fas', 'envelope']" />
                <input type="email" placeholder="Correo electrónico" :value="formData.email"
                    @input="updateField('email', ($event.target as HTMLInputElement).value)">
            </div>
        </div>

        <div class="navigation-buttons">
            <button class="nav-btn next-btn" @click="$emit('next-step')" :disabled="!isStepValid">SIGUIENTE</button>
        </div>
    </div>
</template>

<script lang="ts">
// ✨ Solución: Eliminamos 'computed' de la importación
import { defineComponent, type PropType } from 'vue';

interface Step1FormData {
    firstName: string;
    lastName: string;
    email: string;
}

interface ComponentData {
    previewImage: string | null;
}

export default defineComponent({
    name: 'AddUserWizardStep1',
    props: {
        formData: {
            type: Object as PropType<Step1FormData>,
            required: true,
        },
    },
    emits: ['update:formData', 'update:image', 'next-step'],
    data(): ComponentData {
        return {
            previewImage: null,
        };
    },
    // La propiedad 'computed' está correctamente definida aquí
    computed: {
        isStepValid(): boolean {
            return !!this.formData.firstName.trim() &&
                !!this.formData.lastName.trim() &&
                !!this.formData.email.trim();
        }
    },
    methods: {
        /**
         * Actualiza un campo de formData y emite el objeto completo al padre.
         */
        updateField(fieldName: keyof Step1FormData, value: string): void {
            const newFormData = { ...this.formData };
            newFormData[fieldName] = value;
            this.$emit('update:formData', newFormData);
        },

        /**
         * Simula un clic en el input de tipo 'file' oculto.
         */
        openFilePicker(): void {
            const fileInput = this.$refs.fileInput as HTMLInputElement | undefined;
            if (fileInput) {
                fileInput.click();
            }
        },

        /**
         * Maneja el cambio de archivo seleccionado.
         */
        handleFileChange(event: Event): void {
            const input = event.target as HTMLInputElement;
            const file = input.files?.[0];

            if (file) {
                const reader = new FileReader();
                reader.onload = (e) => {
                    this.previewImage = e.target?.result as string;
                    this.$emit('update:image', file);
                };
                reader.readAsDataURL(file);
            }
        },
    },
});
</script>

<style scoped>
/* ... (Estilos sin cambios) ... */
.step-title {
    text-align: center;
    font-size: 18px;
    color: #252525;
    margin-bottom: 20px;
    font-weight: normal;
}

.form-section {
    display: flex;
    flex-direction: column;
    align-items: center;
    width: 100%;
}

.profile-picture {
    display: flex;
    flex-direction: column;
    align-items: center;
    margin-bottom: 20px;
}

.image-placeholder {
    width: 100px;
    height: 100px;
    background-color: #eee;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 60px;
    color: #505050;
    margin-bottom: 10px;
    overflow: hidden;
    cursor: pointer;
}

.profile-image {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.choose-text {
    font-size: 12px;
    color: #707070;
    cursor: pointer;
    transition: color 0.2s;
}

.choose-text:hover {
    color: #0092d6;
}

.hidden-file-input {
    display: none;
}

.input-group {
    display: flex;
    gap: 20px;
    width: 100%;
}

.input-field {
    flex: 1;
    position: relative;
    margin-bottom: 20px;
}

.input-field.full-width {
    flex: none;
    width: 100%;
}

/* Estilo para los íconos (font-awesome-icon) */
.input-field svg {
    position: absolute;
    left: 15px;
    top: 50%;
    transform: translateY(-50%);
    color: #ccc;
    font-size: 16px;
    z-index: 1;
}

input[type="text"],
input[type="email"] {
    width: 100%;
    padding: 10px 10px 10px 40px;
    border: 1px solid #ddd;
    border-radius: 5px;
    font-size: 16px;
    outline: none;
    box-sizing: border-box;
    transition: border-color 0.3s;
}

input[type="text"]:focus,
input[type="email"]:focus {
    border-color: #0092d6;
}

.navigation-buttons {
    display: flex;
    justify-content: flex-end;
}

.nav-btn {
    padding: 10px 25px;
    border: none;
    border-radius: 5px;
    font-weight: bold;
    cursor: pointer;
    transition: background-color 0.3s ease;
}

.next-btn {
    background-color: #0092d6;
    color: #fff;
}

.next-btn:hover:not(:disabled) {
    background-color: #0079b3;
}

/* 🟢 Estilo para el botón deshabilitado */
.nav-btn:disabled {
    background-color: #cccccc;
    cursor: not-allowed;
    opacity: 0.6;
}
</style>